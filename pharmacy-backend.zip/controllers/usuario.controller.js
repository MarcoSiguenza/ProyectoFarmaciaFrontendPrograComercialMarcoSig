const models = require('../models');
const { Usuario } = models;

// GET /api/usuarios
exports.getAll = async (req, res) => {
  try {
    const registros = await Usuario.findAll({
      include: [{ model: models.Rol, as: 'rol' }],
      order: [['id_usuario', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener usuarios', error: error.message });
  }
};

// GET /api/usuarios/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Usuario.findByPk(req.params.id, { include: [{ model: models.Rol, as: 'rol' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Usuario no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/usuarios
exports.create = async (req, res) => {
  try {
    const nuevo = await Usuario.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/usuarios/:id
exports.update = async (req, res) => {
  try {
    const registro = await Usuario.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Usuario no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/usuarios/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Usuario.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Usuario no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Usuario eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
