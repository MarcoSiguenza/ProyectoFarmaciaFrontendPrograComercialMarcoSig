const models = require('../models');
const { Presentacion } = models;

// GET /api/presentaciones
exports.getAll = async (req, res) => {
  try {
    const registros = await Presentacion.findAll({
      include: [],
      order: [['id_presentacion', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener presentaciones', error: error.message });
  }
};

// GET /api/presentaciones/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Presentacion.findByPk(req.params.id, { include: [] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Presentacion no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/presentaciones
exports.create = async (req, res) => {
  try {
    const nuevo = await Presentacion.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/presentaciones/:id
exports.update = async (req, res) => {
  try {
    const registro = await Presentacion.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Presentacion no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/presentaciones/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Presentacion.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Presentacion no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Presentacion eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
