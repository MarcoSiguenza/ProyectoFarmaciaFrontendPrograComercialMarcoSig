const jwt = require('jsonwebtoken');
const models = require('../models');
const { Usuario, Rol } = models;

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { usuario, password } = req.body;

    if (!usuario || !password) {
      return res.status(400).json({ mensaje: 'Usuario y contraseña son requeridos' });
    }

    const usuarioEncontrado = await Usuario.findOne({
      where: { usuario },
      include: [{ model: Rol, as: 'rol' }]
    });

    if (!usuarioEncontrado) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas' });
    }

    if (!usuarioEncontrado.estado_usuario) {
      return res.status(403).json({ mensaje: 'Usuario inactivo, contacte al administrador' });
    }

    const passwordValido = await usuarioEncontrado.validarPassword(password);
    if (!passwordValido) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas' });
    }

    const token = jwt.sign(
      {
        id_usuario: usuarioEncontrado.id_usuario,
        usuario: usuarioEncontrado.usuario,
        id_rol: usuarioEncontrado.id_rol
      },
      process.env.JWT_SECRET || 'clave_secreta_farmacia',
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    res.json({ token, usuario: usuarioEncontrado });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al iniciar sesión', error: error.message });
  }
};

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const nuevoUsuario = await Usuario.create(req.body);
    res.status(201).json(nuevoUsuario);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al registrar usuario', error: error.message });
  }
};

// GET /api/auth/me
exports.me = async (req, res) => {
  try {
    const usuario = await Usuario.findByPk(req.usuario.id_usuario, {
      include: [{ model: Rol, as: 'rol' }]
    });
    res.json(usuario);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el usuario', error: error.message });
  }
};
