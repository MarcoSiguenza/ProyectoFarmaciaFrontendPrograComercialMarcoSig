const models = require('../models');
const { MetodoPago } = models;

// GET /api/metodos_pago
exports.getAll = async (req, res) => {
  try {
    const registros = await MetodoPago.findAll({
      include: [],
      order: [['id_metodo_pago', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener metodos_pago', error: error.message });
  }
};

// GET /api/metodos_pago/:id
exports.getById = async (req, res) => {
  try {
    const registro = await MetodoPago.findByPk(req.params.id, { include: [] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'MetodoPago no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/metodos_pago
exports.create = async (req, res) => {
  try {
    const nuevo = await MetodoPago.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/metodos_pago/:id
exports.update = async (req, res) => {
  try {
    const registro = await MetodoPago.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'MetodoPago no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/metodos_pago/:id
exports.remove = async (req, res) => {
  try {
    const registro = await MetodoPago.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'MetodoPago no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'MetodoPago eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
