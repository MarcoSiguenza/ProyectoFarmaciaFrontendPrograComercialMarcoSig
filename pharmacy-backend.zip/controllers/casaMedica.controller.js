const models = require('../models');
const { CasaMedica } = models;

// GET /api/casas_medicas
exports.getAll = async (req, res) => {
  try {
    const registros = await CasaMedica.findAll({
      include: [],
      order: [['id_casa_medica', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener casas_medicas', error: error.message });
  }
};

// GET /api/casas_medicas/:id
exports.getById = async (req, res) => {
  try {
    const registro = await CasaMedica.findByPk(req.params.id, { include: [] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'CasaMedica no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/casas_medicas
exports.create = async (req, res) => {
  try {
    const nuevo = await CasaMedica.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/casas_medicas/:id
exports.update = async (req, res) => {
  try {
    const registro = await CasaMedica.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'CasaMedica no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/casas_medicas/:id
exports.remove = async (req, res) => {
  try {
    const registro = await CasaMedica.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'CasaMedica no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'CasaMedica eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
