const { Op, fn, col } = require('sequelize');
const models = require('../models');
const { Cliente, Medicamento, Venta, Proveedor, Compra, Lote } = models;

// GET /api/dashboard/resumen
exports.resumen = async (req, res) => {
  try {
    const [totalClientes, totalMedicamentos, totalProveedores, totalVentas, totalCompras] =
      await Promise.all([
        Cliente.count(),
        Medicamento.count(),
        Proveedor.count(),
        Venta.count(),
        Compra.count()
      ]);

    const sumaVentas = await Venta.sum('total_venta');
    const sumaCompras = await Compra.sum('total_compra');

    const hoy = new Date();
    const en30dias = new Date();
    en30dias.setDate(hoy.getDate() + 30);

    const lotesPorVencer = await Lote.count({
      where: {
        fecha_vencimiento: { [Op.between]: [hoy, en30dias] },
        estado_lote: true
      }
    });

    const ultimasVentas = await Venta.findAll({
      limit: 5,
      order: [['id_venta', 'DESC']],
      include: [{ model: models.Cliente, as: 'cliente' }]
    });

    res.json({
      totalClientes,
      totalMedicamentos,
      totalProveedores,
      totalVentas,
      totalCompras,
      sumaVentas: sumaVentas || 0,
      sumaCompras: sumaCompras || 0,
      lotesPorVencer,
      ultimasVentas
    });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el resumen', error: error.message });
  }
};
