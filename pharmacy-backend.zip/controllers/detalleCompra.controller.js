const models = require('../models');
const { DetalleCompra } = models;

// GET /api/detalle_compras
exports.getAll = async (req, res) => {
  try {
    const registros = await DetalleCompra.findAll({
      include: [{ model: models.Compra, as: 'compra' }, { model: models.Proveedor, as: 'proveedor' }, { model: models.Medicamento, as: 'medicamento' }],
      order: [['id_detalle_compra', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener detalle_compras', error: error.message });
  }
};

// GET /api/detalle_compras/:id
exports.getById = async (req, res) => {
  try {
    const registro = await DetalleCompra.findByPk(req.params.id, { include: [{ model: models.Compra, as: 'compra' }, { model: models.Proveedor, as: 'proveedor' }, { model: models.Medicamento, as: 'medicamento' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleCompra no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/detalle_compras
exports.create = async (req, res) => {
  try {
    const nuevo = await DetalleCompra.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/detalle_compras/:id
exports.update = async (req, res) => {
  try {
    const registro = await DetalleCompra.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleCompra no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/detalle_compras/:id
exports.remove = async (req, res) => {
  try {
    const registro = await DetalleCompra.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleCompra no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'DetalleCompra eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
