const models = require('../models');
const { DetalleVenta } = models;

// GET /api/detalle_ventas
exports.getAll = async (req, res) => {
  try {
    const registros = await DetalleVenta.findAll({
      include: [{ model: models.Medicamento, as: 'medicamento' }, { model: models.Venta, as: 'venta' }],
      order: [['id_detalle_venta', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener detalle_ventas', error: error.message });
  }
};

// GET /api/detalle_ventas/:id
exports.getById = async (req, res) => {
  try {
    const registro = await DetalleVenta.findByPk(req.params.id, { include: [{ model: models.Medicamento, as: 'medicamento' }, { model: models.Venta, as: 'venta' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleVenta no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/detalle_ventas
exports.create = async (req, res) => {
  try {
    const nuevo = await DetalleVenta.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/detalle_ventas/:id
exports.update = async (req, res) => {
  try {
    const registro = await DetalleVenta.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleVenta no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/detalle_ventas/:id
exports.remove = async (req, res) => {
  try {
    const registro = await DetalleVenta.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'DetalleVenta no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'DetalleVenta eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
