const models = require('../models');
const { Proveedor } = models;

// GET /api/proveedores
exports.getAll = async (req, res) => {
  try {
    const registros = await Proveedor.findAll({
      include: [{ model: models.CasaMedica, as: 'casaMedica' }],
      order: [['id_proveedor', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener proveedores', error: error.message });
  }
};

// GET /api/proveedores/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Proveedor.findByPk(req.params.id, { include: [{ model: models.CasaMedica, as: 'casaMedica' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Proveedor no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/proveedores
exports.create = async (req, res) => {
  try {
    const nuevo = await Proveedor.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/proveedores/:id
exports.update = async (req, res) => {
  try {
    const registro = await Proveedor.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Proveedor no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/proveedores/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Proveedor.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Proveedor no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Proveedor eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
