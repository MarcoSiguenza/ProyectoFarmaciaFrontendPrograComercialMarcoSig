const models = require('../models');
const { Medicamento } = models;

// GET /api/medicamentos
exports.getAll = async (req, res) => {
  try {
    const registros = await Medicamento.findAll({
      include: [{ model: models.Presentacion, as: 'presentacion' }],
      order: [['id_medicamento', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener medicamentos', error: error.message });
  }
};

// GET /api/medicamentos/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Medicamento.findByPk(req.params.id, { include: [{ model: models.Presentacion, as: 'presentacion' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Medicamento no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/medicamentos
exports.create = async (req, res) => {
  try {
    const nuevo = await Medicamento.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/medicamentos/:id
exports.update = async (req, res) => {
  try {
    const registro = await Medicamento.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Medicamento no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/medicamentos/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Medicamento.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Medicamento no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Medicamento eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
