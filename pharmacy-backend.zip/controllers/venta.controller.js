const models = require('../models');
const { Venta } = models;

// GET /api/ventas
exports.getAll = async (req, res) => {
  try {
    const registros = await Venta.findAll({
      include: [{ model: models.Usuario, as: 'usuario' }, { model: models.Cliente, as: 'cliente' }],
      order: [['id_venta', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener ventas', error: error.message });
  }
};

// GET /api/ventas/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Venta.findByPk(req.params.id, { include: [{ model: models.Usuario, as: 'usuario' }, { model: models.Cliente, as: 'cliente' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Venta no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/ventas
exports.create = async (req, res) => {
  try {
    const nuevo = await Venta.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/ventas/:id
exports.update = async (req, res) => {
  try {
    const registro = await Venta.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Venta no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/ventas/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Venta.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Venta no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Venta eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
