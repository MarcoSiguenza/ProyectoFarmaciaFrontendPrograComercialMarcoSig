const models = require('../models');
const { Cliente } = models;

// GET /api/clientes
exports.getAll = async (req, res) => {
  try {
    const registros = await Cliente.findAll({
      include: [],
      order: [['id_cliente', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener clientes', error: error.message });
  }
};

// GET /api/clientes/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Cliente.findByPk(req.params.id, { include: [] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Cliente no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/clientes
exports.create = async (req, res) => {
  try {
    const nuevo = await Cliente.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/clientes/:id
exports.update = async (req, res) => {
  try {
    const registro = await Cliente.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Cliente no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/clientes/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Cliente.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Cliente no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Cliente eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
