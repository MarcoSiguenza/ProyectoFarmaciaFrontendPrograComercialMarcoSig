const models = require('../models');
const { Lote } = models;

// GET /api/lotes
exports.getAll = async (req, res) => {
  try {
    const registros = await Lote.findAll({
      include: [{ model: models.Medicamento, as: 'medicamento' }],
      order: [['id_lote', 'ASC']]
    });
    res.json(registros);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener lotes', error: error.message });
  }
};

// GET /api/lotes/:id
exports.getById = async (req, res) => {
  try {
    const registro = await Lote.findByPk(req.params.id, { include: [{ model: models.Medicamento, as: 'medicamento' }] });
    if (!registro) {
      return res.status(404).json({ mensaje: 'Lote no encontrado' });
    }
    res.json(registro);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener el registro', error: error.message });
  }
};

// POST /api/lotes
exports.create = async (req, res) => {
  try {
    const nuevo = await Lote.create(req.body);
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear el registro', error: error.message });
  }
};

// PUT /api/lotes/:id
exports.update = async (req, res) => {
  try {
    const registro = await Lote.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Lote no encontrado' });
    }
    await registro.update(req.body);
    res.json(registro);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al actualizar el registro', error: error.message });
  }
};

// DELETE /api/lotes/:id
exports.remove = async (req, res) => {
  try {
    const registro = await Lote.findByPk(req.params.id);
    if (!registro) {
      return res.status(404).json({ mensaje: 'Lote no encontrado' });
    }
    await registro.destroy();
    res.json({ mensaje: 'Lote eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al eliminar el registro', error: error.message });
  }
};
