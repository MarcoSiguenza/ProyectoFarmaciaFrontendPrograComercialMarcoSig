# Backend - Sistema de Farmacia

API REST construida con **Node.js + Express + Sequelize (MySQL)** siguiendo arquitectura **MVC**.

## Estructura

```
pharmacy-backend/
├── config/
│   └── database.js          # Configuración de conexión Sequelize
├── models/                  # 14 modelos (uno por entidad del diagrama) + index.js (loader/asociaciones)
├── controllers/             # Lógica CRUD por entidad + auth + dashboard
├── routes/                  # Rutas Express por entidad + index.js agregador
├── middlewares/
│   └── auth.middleware.js   # Verificación de JWT
├── server.js                # Punto de entrada
├── .env.example             # Variables de entorno de ejemplo
└── package.json
```

## Requisitos

- Node.js 22+
- MySQL 8+

## Instalación

```bash
npm install
cp .env.example .env
# Edita .env con tus credenciales de MySQL
```

## Base de datos

Puedes crear la base de datos de dos formas:

1. **Recomendado:** ejecuta el script `farmacia_db.sql` (incluido aparte) directamente en MySQL:
   ```bash
   mysql -u root -p < farmacia_db.sql
   ```
2. O deja que Sequelize cree las tablas automáticamente al iniciar el servidor (usa `sequelize.sync()` en `server.js`). Si usas el script SQL, comenta esa línea para evitar conflictos.

## Ejecución

```bash
npm run dev     # con nodemon (desarrollo)
npm start       # producción
```

El servidor corre por defecto en `http://localhost:3000`.

## Endpoints

Todas las entidades exponen el mismo patrón CRUD bajo `/api/<recurso>`:

| Método | Ruta                    | Descripción            |
|--------|-------------------------|-------------------------|
| GET    | /api/:recurso           | Listar todos            |
| GET    | /api/:recurso/:id       | Obtener uno              |
| POST   | /api/:recurso           | Crear                    |
| PUT    | /api/:recurso/:id       | Actualizar               |
| DELETE | /api/:recurso/:id       | Eliminar                 |

Recursos disponibles: `casas_medicas`, `proveedores`, `compras`, `detalle_compras`, `presentaciones`,
`medicamentos`, `lotes`, `clientes`, `roles`, `usuarios`, `ventas`, `detalle_ventas`, `metodos_pago`,
`detalle_metodos_pago`.

### Autenticación

- `POST /api/auth/login` — `{ usuario, password }` → devuelve `{ token, usuario }`
- `POST /api/auth/register` — crea un usuario
- `GET /api/auth/me` — requiere header `Authorization: Bearer <token>`

### Dashboard

- `GET /api/dashboard/resumen` — KPIs para las tarjetas del panel (clientes, medicamentos, ventas, etc.)

## Notas

- Las contraseñas de `Usuario` se hashean automáticamente con bcrypt antes de guardarse.
- Los campos `estado_*` son booleanos (activo/inactivo) para borrado lógico.
- Las relaciones son todas 1:N, según el diagrama entregado (sin tablas pivote M:N).
