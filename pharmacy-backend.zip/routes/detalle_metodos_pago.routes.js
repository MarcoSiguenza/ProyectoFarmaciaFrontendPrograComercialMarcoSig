const express = require('express');
const router = express.Router();
const detalleMetodoPagoController = require('../controllers/detalleMetodoPago.controller');

router.get('/', detalleMetodoPagoController.getAll);
router.get('/:id', detalleMetodoPagoController.getById);
router.post('/', detalleMetodoPagoController.create);
router.put('/:id', detalleMetodoPagoController.update);
router.delete('/:id', detalleMetodoPagoController.remove);

module.exports = router;
