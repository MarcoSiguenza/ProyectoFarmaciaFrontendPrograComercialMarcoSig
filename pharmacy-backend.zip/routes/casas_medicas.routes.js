const express = require('express');
const router = express.Router();
const casaMedicaController = require('../controllers/casaMedica.controller');

router.get('/', casaMedicaController.getAll);
router.get('/:id', casaMedicaController.getById);
router.post('/', casaMedicaController.create);
router.put('/:id', casaMedicaController.update);
router.delete('/:id', casaMedicaController.remove);

module.exports = router;
