const express = require('express');
const router = express.Router();
const loteController = require('../controllers/lote.controller');

router.get('/', loteController.getAll);
router.get('/:id', loteController.getById);
router.post('/', loteController.create);
router.put('/:id', loteController.update);
router.delete('/:id', loteController.remove);

module.exports = router;
