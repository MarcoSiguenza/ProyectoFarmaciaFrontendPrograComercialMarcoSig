const express = require('express');
const router = express.Router();
const compraController = require('../controllers/compra.controller');

router.get('/', compraController.getAll);
router.get('/:id', compraController.getById);
router.post('/', compraController.create);
router.put('/:id', compraController.update);
router.delete('/:id', compraController.remove);

module.exports = router;
