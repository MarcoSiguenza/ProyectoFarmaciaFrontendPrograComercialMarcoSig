const express = require('express');
const router = express.Router();
const presentacionController = require('../controllers/presentacion.controller');

router.get('/', presentacionController.getAll);
router.get('/:id', presentacionController.getById);
router.post('/', presentacionController.create);
router.put('/:id', presentacionController.update);
router.delete('/:id', presentacionController.remove);

module.exports = router;
