const express = require('express');
const router = express.Router();
const detalleCompraController = require('../controllers/detalleCompra.controller');

router.get('/', detalleCompraController.getAll);
router.get('/:id', detalleCompraController.getById);
router.post('/', detalleCompraController.create);
router.put('/:id', detalleCompraController.update);
router.delete('/:id', detalleCompraController.remove);

module.exports = router;
