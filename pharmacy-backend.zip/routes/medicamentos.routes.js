const express = require('express');
const router = express.Router();
const medicamentoController = require('../controllers/medicamento.controller');

router.get('/', medicamentoController.getAll);
router.get('/:id', medicamentoController.getById);
router.post('/', medicamentoController.create);
router.put('/:id', medicamentoController.update);
router.delete('/:id', medicamentoController.remove);

module.exports = router;
