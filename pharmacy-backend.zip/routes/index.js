const express = require('express');
const router = express.Router();

router.use('/casas_medicas', require('./casas_medicas.routes'));
router.use('/proveedores', require('./proveedores.routes'));
router.use('/compras', require('./compras.routes'));
router.use('/detalle_compras', require('./detalle_compras.routes'));
router.use('/presentaciones', require('./presentaciones.routes'));
router.use('/medicamentos', require('./medicamentos.routes'));
router.use('/lotes', require('./lotes.routes'));
router.use('/clientes', require('./clientes.routes'));
router.use('/roles', require('./roles.routes'));
router.use('/usuarios', require('./usuarios.routes'));
router.use('/ventas', require('./ventas.routes'));
router.use('/detalle_ventas', require('./detalle_ventas.routes'));
router.use('/metodos_pago', require('./metodos_pago.routes'));
router.use('/detalle_metodos_pago', require('./detalle_metodos_pago.routes'));
router.use('/auth', require('./auth.routes'));
router.use('/dashboard', require('./dashboard.routes'));

module.exports = router;
