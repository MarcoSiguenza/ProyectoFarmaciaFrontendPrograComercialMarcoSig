module.exports = (sequelize, DataTypes) => {
  const Venta = sequelize.define('Venta', {
    id_venta: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    fecha_venta: {
      type: DataTypes.DATE,
      allowNull: false
    },
    estado_venta: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    total_venta: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    }
  }, {
    tableName: 'ventas',
    underscored: true,
    timestamps: true
  });

  Venta.associate = (models) => {
    Venta.belongsTo(models.Usuario, { foreignKey: 'id_usuario', as: 'usuario' });
    Venta.belongsTo(models.Cliente, { foreignKey: 'id_cliente', as: 'cliente' });
    Venta.hasMany(models.DetalleVenta, { foreignKey: 'id_venta', as: 'detalles' });
    Venta.hasMany(models.DetalleMetodoPago, { foreignKey: 'id_venta', as: 'detalleMetodosPago' });
  };

  return Venta;
};
