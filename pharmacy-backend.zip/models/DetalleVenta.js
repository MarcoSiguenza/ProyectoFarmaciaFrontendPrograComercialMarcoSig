module.exports = (sequelize, DataTypes) => {
  const DetalleVenta = sequelize.define('DetalleVenta', {
    id_detalle_venta: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    cantidad_detalle_venta: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    subtotal_detalle_venta: {
      type: DataTypes.DECIMAL(12,2),
      allowNull: false
    },
    estado_detalle_venta: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'detalle_ventas',
    underscored: true,
    timestamps: true
  });

  DetalleVenta.associate = (models) => {
    DetalleVenta.belongsTo(models.Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });
    DetalleVenta.belongsTo(models.Venta, { foreignKey: 'id_venta', as: 'venta' });

  };

  return DetalleVenta;
};
