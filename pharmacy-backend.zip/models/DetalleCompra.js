module.exports = (sequelize, DataTypes) => {
  const DetalleCompra = sequelize.define('DetalleCompra', {
    id_detalle_compra: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    cantidad_compra: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    subtotal_compra: {
      type: DataTypes.DECIMAL(12,2),
      allowNull: false
    },
    estado_compra: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'detalle_compras',
    underscored: true,
    timestamps: true
  });

  DetalleCompra.associate = (models) => {
    DetalleCompra.belongsTo(models.Compra, { foreignKey: 'id_compra', as: 'compra' });
    DetalleCompra.belongsTo(models.Proveedor, { foreignKey: 'id_proveedor', as: 'proveedor' });
    DetalleCompra.belongsTo(models.Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });

  };

  return DetalleCompra;
};
