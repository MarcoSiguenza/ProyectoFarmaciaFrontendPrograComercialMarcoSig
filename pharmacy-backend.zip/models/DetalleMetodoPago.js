module.exports = (sequelize, DataTypes) => {
  const DetalleMetodoPago = sequelize.define('DetalleMetodoPago', {
    id_detalle_metodos_pago: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    cantidad_detalle_metodos_pago: {
      type: DataTypes.DECIMAL(12,2),
      allowNull: false
    },
    estado_detalle_metodos_pago: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'detalle_metodos_pago',
    underscored: true,
    timestamps: true
  });

  DetalleMetodoPago.associate = (models) => {
    DetalleMetodoPago.belongsTo(models.MetodoPago, { foreignKey: 'id_metodo_pago', as: 'metodoPago' });
    DetalleMetodoPago.belongsTo(models.Venta, { foreignKey: 'id_venta', as: 'venta' });

  };

  return DetalleMetodoPago;
};
