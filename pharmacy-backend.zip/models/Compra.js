module.exports = (sequelize, DataTypes) => {
  const Compra = sequelize.define('Compra', {
    id_compra: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    fecha_compra: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    total_compra: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    estado_compra: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'compras',
    underscored: true,
    timestamps: true
  });

  Compra.associate = (models) => {
    Compra.belongsTo(models.Proveedor, { foreignKey: 'id_proveedor', as: 'proveedor' });
    Compra.hasMany(models.DetalleCompra, { foreignKey: 'id_compra', as: 'detalles' });
  };

  return Compra;
};
