module.exports = (sequelize, DataTypes) => {
  const Cliente = sequelize.define('Cliente', {
    id_cliente: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_cliente: {
      type: DataTypes.STRING,
      allowNull: false
    },
    nit_cliente: {
      type: DataTypes.STRING
    },
    estado_cliente: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'clientes',
    underscored: true,
    timestamps: true
  });

  Cliente.associate = (models) => {

    Cliente.hasMany(models.Venta, { foreignKey: 'id_cliente', as: 'ventas' });
  };

  return Cliente;
};
