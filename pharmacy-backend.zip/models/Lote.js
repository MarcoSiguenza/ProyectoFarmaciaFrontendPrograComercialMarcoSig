module.exports = (sequelize, DataTypes) => {
  const Lote = sequelize.define('Lote', {
    id_lote: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    fecha_vencimiento: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    fecha_produccion: {
      type: DataTypes.DATEONLY
    },
    precio_lote: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    estado_lote: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    existencia_lote: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    }
  }, {
    tableName: 'lotes',
    underscored: true,
    timestamps: true
  });

  Lote.associate = (models) => {
    Lote.belongsTo(models.Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });

  };

  return Lote;
};
