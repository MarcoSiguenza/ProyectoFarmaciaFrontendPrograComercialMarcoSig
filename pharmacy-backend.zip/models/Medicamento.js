module.exports = (sequelize, DataTypes) => {
  const Medicamento = sequelize.define('Medicamento', {
    id_medicamento: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    codigo_barras_medicamento: {
      type: DataTypes.STRING
    },
    nombre_medicamento: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cantidad_por_paquete: {
      type: DataTypes.INTEGER,
      defaultValue: 1
    },
    precio_mayorista: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    precio_minimo: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    precio_venta: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    componente_activo: {
      type: DataTypes.STRING
    },
    estado_medicamento: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    venta_libre: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    existencia_total_medicamento: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    }
  }, {
    tableName: 'medicamentos',
    underscored: true,
    timestamps: true
  });

  Medicamento.associate = (models) => {
    Medicamento.belongsTo(models.Presentacion, { foreignKey: 'id_presentacion', as: 'presentacion' });
    Medicamento.hasMany(models.Lote, { foreignKey: 'id_medicamento', as: 'lotes' });
    Medicamento.hasMany(models.DetalleCompra, { foreignKey: 'id_medicamento', as: 'detalleCompras' });
    Medicamento.hasMany(models.DetalleVenta, { foreignKey: 'id_medicamento', as: 'detalleVentas' });
  };

  return Medicamento;
};
