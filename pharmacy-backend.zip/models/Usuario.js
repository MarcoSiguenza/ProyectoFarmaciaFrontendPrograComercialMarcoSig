const bcrypt = require('bcryptjs');

module.exports = (sequelize, DataTypes) => {
  const Usuario = sequelize.define('Usuario', {
    id_usuario: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    usuario: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    nombre_usuario: {
      type: DataTypes.STRING
    },
    telefono_usuario: {
      type: DataTypes.STRING
    },
    correo_usuario: {
      type: DataTypes.STRING
    },
    dpi_usuario: {
      type: DataTypes.STRING
    },
    estado_usuario: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'usuarios',
    underscored: true,
    timestamps: true,
    hooks: {
      beforeCreate: async (usuario) => {
        if (usuario.password) {
          usuario.password = await bcrypt.hash(usuario.password, 10);
        }
      },
      beforeUpdate: async (usuario) => {
        if (usuario.changed('password')) {
          usuario.password = await bcrypt.hash(usuario.password, 10);
        }
      }
    }
  });

  Usuario.prototype.validarPassword = function (passwordPlano) {
    return bcrypt.compare(passwordPlano, this.password);
  };

  Usuario.prototype.toJSON = function () {
    const values = { ...this.get() };
    delete values.password;
    return values;
  };

  Usuario.associate = (models) => {
    Usuario.belongsTo(models.Rol, { foreignKey: 'id_rol', as: 'rol' });
    Usuario.hasMany(models.Venta, { foreignKey: 'id_usuario', as: 'ventas' });
  };

  return Usuario;
};
