module.exports = (sequelize, DataTypes) => {
  const MetodoPago = sequelize.define('MetodoPago', {
    id_metodo_pago: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_metodo_pago: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cuenta_metodo_pago: {
      type: DataTypes.STRING
    },
    estado_metodo_pago: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'metodos_pago',
    underscored: true,
    timestamps: true
  });

  MetodoPago.associate = (models) => {

    MetodoPago.hasMany(models.DetalleMetodoPago, { foreignKey: 'id_metodo_pago', as: 'detalles' });
  };

  return MetodoPago;
};
