module.exports = (sequelize, DataTypes) => {
  const CasaMedica = sequelize.define('CasaMedica', {
    id_casa_medica: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_casa_medica: {
      type: DataTypes.STRING,
      allowNull: false
    },
    estado_casa_medica: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'casas_medicas',
    underscored: true,
    timestamps: true
  });

  CasaMedica.associate = (models) => {

    CasaMedica.hasMany(models.Proveedor, { foreignKey: 'id_casa_medica', as: 'proveedores' });
  };

  return CasaMedica;
};
