module.exports = (sequelize, DataTypes) => {
  const Presentacion = sequelize.define('Presentacion', {
    id_presentacion: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_presentacion: {
      type: DataTypes.STRING,
      allowNull: false
    },
    estado_presentacion: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'presentaciones',
    underscored: true,
    timestamps: true
  });

  Presentacion.associate = (models) => {

    Presentacion.hasMany(models.Medicamento, { foreignKey: 'id_presentacion', as: 'medicamentos' });
  };

  return Presentacion;
};
