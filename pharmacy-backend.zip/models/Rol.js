module.exports = (sequelize, DataTypes) => {
  const Rol = sequelize.define('Rol', {
    id_rol: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_rol: {
      type: DataTypes.STRING,
      allowNull: false
    },
    estado_rol: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    tableName: 'roles',
    underscored: true,
    timestamps: true
  });

  Rol.associate = (models) => {

    Rol.hasMany(models.Usuario, { foreignKey: 'id_rol', as: 'usuarios' });
  };

  return Rol;
};
