module.exports = (sequelize, DataTypes) => {
  const Proveedor = sequelize.define('Proveedor', {
    id_proveedor: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre_proveedor: {
      type: DataTypes.STRING,
      allowNull: false
    },
    estado_proveedor: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    telefono_proveedor: {
      type: DataTypes.STRING
    },
    direccion_proveedor: {
      type: DataTypes.STRING
    },
    correo_proveedor: {
      type: DataTypes.STRING
    },
    total_adquirido_proveedor: {
      type: DataTypes.DECIMAL(12,2),
      defaultValue: 0
    },
    cantidad_adquirido_proveedor: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    }
  }, {
    tableName: 'proveedores',
    underscored: true,
    timestamps: true
  });

  Proveedor.associate = (models) => {
    Proveedor.belongsTo(models.CasaMedica, { foreignKey: 'id_casa_medica', as: 'casaMedica' });
    Proveedor.hasMany(models.Compra, { foreignKey: 'id_proveedor', as: 'compras' });
    Proveedor.hasMany(models.DetalleCompra, { foreignKey: 'id_proveedor', as: 'detalleCompras' });
  };

  return Proveedor;
};
