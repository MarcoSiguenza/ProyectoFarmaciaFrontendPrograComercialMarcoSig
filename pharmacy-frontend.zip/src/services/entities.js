// Archivo generado: configuración de entidades para el CRUD genérico.
// No editar a mano campo por campo; refleja el diagrama relacional del backend.

export const entidades = [
  {
    "name": "CasaMedica",
    "label": "Casa Medica",
    "table": "casas_medicas",
    "endpoint": "casas_medicas",
    "pk": "id_casa_medica",
    "icon": "🏥",
    "fields": [
      {
        "name": "nombre_casa_medica",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "estado_casa_medica",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": []
  },
  {
    "name": "Proveedor",
    "label": "Proveedor",
    "table": "proveedores",
    "endpoint": "proveedores",
    "pk": "id_proveedor",
    "icon": "🚚",
    "fields": [
      {
        "name": "nombre_proveedor",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "estado_proveedor",
        "label": "Estado",
        "type": "boolean",
        "required": false
      },
      {
        "name": "telefono_proveedor",
        "label": "Telefono",
        "type": "text",
        "required": false
      },
      {
        "name": "direccion_proveedor",
        "label": "Direccion",
        "type": "text",
        "required": false
      },
      {
        "name": "correo_proveedor",
        "label": "Correo",
        "type": "text",
        "required": false
      },
      {
        "name": "total_adquirido_proveedor",
        "label": "Total adquirido",
        "type": "decimal",
        "required": false
      },
      {
        "name": "cantidad_adquirido_proveedor",
        "label": "Cantidad adquirido",
        "type": "number",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_casa_medica",
        "label": "Id",
        "as": "casaMedica",
        "endpoint": "casas_medicas",
        "pk": "id_casa_medica",
        "displayField": "nombre_casa_medica"
      }
    ]
  },
  {
    "name": "Compra",
    "label": "Compra",
    "table": "compras",
    "endpoint": "compras",
    "pk": "id_compra",
    "icon": "🧾",
    "fields": [
      {
        "name": "fecha_compra",
        "label": "Fecha",
        "type": "date",
        "required": true
      },
      {
        "name": "total_compra",
        "label": "Total",
        "type": "decimal",
        "required": false
      },
      {
        "name": "estado_compra",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_proveedor",
        "label": "Id",
        "as": "proveedor",
        "endpoint": "proveedores",
        "pk": "id_proveedor",
        "displayField": "nombre_proveedor"
      }
    ]
  },
  {
    "name": "DetalleCompra",
    "label": "Detalle Compra",
    "table": "detalle_compras",
    "endpoint": "detalle_compras",
    "pk": "id_detalle_compra",
    "icon": "📦",
    "fields": [
      {
        "name": "cantidad_compra",
        "label": "Cantidad",
        "type": "number",
        "required": true
      },
      {
        "name": "subtotal_compra",
        "label": "Subtotal",
        "type": "decimal",
        "required": true
      },
      {
        "name": "estado_compra",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_compra",
        "label": "Id",
        "as": "compra",
        "endpoint": "compras",
        "pk": "id_compra",
        "displayField": "fecha_compra"
      },
      {
        "fk": "id_proveedor",
        "label": "Id",
        "as": "proveedor",
        "endpoint": "proveedores",
        "pk": "id_proveedor",
        "displayField": "nombre_proveedor"
      },
      {
        "fk": "id_medicamento",
        "label": "Id",
        "as": "medicamento",
        "endpoint": "medicamentos",
        "pk": "id_medicamento",
        "displayField": "nombre_medicamento"
      }
    ]
  },
  {
    "name": "Presentacion",
    "label": "Presentacion",
    "table": "presentaciones",
    "endpoint": "presentaciones",
    "pk": "id_presentacion",
    "icon": "💊",
    "fields": [
      {
        "name": "nombre_presentacion",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "estado_presentacion",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": []
  },
  {
    "name": "Medicamento",
    "label": "Medicamento",
    "table": "medicamentos",
    "endpoint": "medicamentos",
    "pk": "id_medicamento",
    "icon": "💉",
    "fields": [
      {
        "name": "codigo_barras_medicamento",
        "label": "Codigo barras",
        "type": "text",
        "required": false
      },
      {
        "name": "nombre_medicamento",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "cantidad_por_paquete",
        "label": "Cantidad por paquete",
        "type": "number",
        "required": false
      },
      {
        "name": "precio_mayorista",
        "label": "Precio mayorista",
        "type": "decimal",
        "required": false
      },
      {
        "name": "precio_minimo",
        "label": "Precio minimo",
        "type": "decimal",
        "required": false
      },
      {
        "name": "precio_venta",
        "label": "Precio",
        "type": "decimal",
        "required": false
      },
      {
        "name": "componente_activo",
        "label": "Componente activo",
        "type": "text",
        "required": false
      },
      {
        "name": "estado_medicamento",
        "label": "Estado",
        "type": "boolean",
        "required": false
      },
      {
        "name": "venta_libre",
        "label": "Venta libre",
        "type": "boolean",
        "required": false
      },
      {
        "name": "existencia_total_medicamento",
        "label": "Existencia total",
        "type": "number",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_presentacion",
        "label": "Id",
        "as": "presentacion",
        "endpoint": "presentaciones",
        "pk": "id_presentacion",
        "displayField": "nombre_presentacion"
      }
    ]
  },
  {
    "name": "Lote",
    "label": "Lote",
    "table": "lotes",
    "endpoint": "lotes",
    "pk": "id_lote",
    "icon": "🗓️",
    "fields": [
      {
        "name": "fecha_vencimiento",
        "label": "Fecha vencimiento",
        "type": "date",
        "required": true
      },
      {
        "name": "fecha_produccion",
        "label": "Fecha produccion",
        "type": "date",
        "required": false
      },
      {
        "name": "precio_lote",
        "label": "Precio",
        "type": "decimal",
        "required": false
      },
      {
        "name": "estado_lote",
        "label": "Estado",
        "type": "boolean",
        "required": false
      },
      {
        "name": "existencia_lote",
        "label": "Existencia",
        "type": "number",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_medicamento",
        "label": "Id",
        "as": "medicamento",
        "endpoint": "medicamentos",
        "pk": "id_medicamento",
        "displayField": "nombre_medicamento"
      }
    ]
  },
  {
    "name": "Cliente",
    "label": "Cliente",
    "table": "clientes",
    "endpoint": "clientes",
    "pk": "id_cliente",
    "icon": "🙍",
    "fields": [
      {
        "name": "nombre_cliente",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "nit_cliente",
        "label": "Nit",
        "type": "text",
        "required": false
      },
      {
        "name": "estado_cliente",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": []
  },
  {
    "name": "Rol",
    "label": "Rol",
    "table": "roles",
    "endpoint": "roles",
    "pk": "id_rol",
    "icon": "🛡️",
    "fields": [
      {
        "name": "nombre_rol",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "name": "estado_rol",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": []
  },
  {
    "name": "Usuario",
    "label": "Usuario",
    "table": "usuarios",
    "endpoint": "usuarios",
    "pk": "id_usuario",
    "icon": "👤",
    "fields": [
      {
        "name": "usuario",
        "label": "Usuario",
        "type": "text",
        "required": true
      },
      {
        "name": "password",
        "label": "Password",
        "type": "text",
        "required": true
      },
      {
        "name": "nombre_usuario",
        "label": "Nombre",
        "type": "text",
        "required": false
      },
      {
        "name": "telefono_usuario",
        "label": "Telefono",
        "type": "text",
        "required": false
      },
      {
        "name": "correo_usuario",
        "label": "Correo",
        "type": "text",
        "required": false
      },
      {
        "name": "dpi_usuario",
        "label": "Dpi",
        "type": "text",
        "required": false
      },
      {
        "name": "estado_usuario",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_rol",
        "label": "Id",
        "as": "rol",
        "endpoint": "roles",
        "pk": "id_rol",
        "displayField": "nombre_rol"
      }
    ]
  },
  {
    "name": "Venta",
    "label": "Venta",
    "table": "ventas",
    "endpoint": "ventas",
    "pk": "id_venta",
    "icon": "🛒",
    "fields": [
      {
        "name": "fecha_venta",
        "label": "Fecha",
        "type": "datetime-local",
        "required": true
      },
      {
        "name": "estado_venta",
        "label": "Estado",
        "type": "boolean",
        "required": false
      },
      {
        "name": "total_venta",
        "label": "Total",
        "type": "decimal",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_usuario",
        "label": "Id",
        "as": "usuario",
        "endpoint": "usuarios",
        "pk": "id_usuario",
        "displayField": "nombre_usuario"
      },
      {
        "fk": "id_cliente",
        "label": "Id",
        "as": "cliente",
        "endpoint": "clientes",
        "pk": "id_cliente",
        "displayField": "nombre_cliente"
      }
    ]
  },
  {
    "name": "DetalleVenta",
    "label": "Detalle Venta",
    "table": "detalle_ventas",
    "endpoint": "detalle_ventas",
    "pk": "id_detalle_venta",
    "icon": "📋",
    "fields": [
      {
        "name": "cantidad_detalle_venta",
        "label": "Cantidad detalle",
        "type": "number",
        "required": true
      },
      {
        "name": "subtotal_detalle_venta",
        "label": "Subtotal detalle",
        "type": "decimal",
        "required": true
      },
      {
        "name": "estado_detalle_venta",
        "label": "Estado detalle",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_medicamento",
        "label": "Id",
        "as": "medicamento",
        "endpoint": "medicamentos",
        "pk": "id_medicamento",
        "displayField": "nombre_medicamento"
      },
      {
        "fk": "id_venta",
        "label": "Id",
        "as": "venta",
        "endpoint": "ventas",
        "pk": "id_venta",
        "displayField": "fecha_venta"
      }
    ]
  },
  {
    "name": "MetodoPago",
    "label": "Metodo Pago",
    "table": "metodos_pago",
    "endpoint": "metodos_pago",
    "pk": "id_metodo_pago",
    "icon": "💳",
    "fields": [
      {
        "name": "nombre_metodo_pago",
        "label": "Nombre metodo",
        "type": "text",
        "required": true
      },
      {
        "name": "cuenta_metodo_pago",
        "label": "Cuenta metodo",
        "type": "text",
        "required": false
      },
      {
        "name": "estado_metodo_pago",
        "label": "Estado metodo",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": []
  },
  {
    "name": "DetalleMetodoPago",
    "label": "Detalle Metodo Pago",
    "table": "detalle_metodos_pago",
    "endpoint": "detalle_metodos_pago",
    "pk": "id_detalle_metodos_pago",
    "icon": "🧮",
    "fields": [
      {
        "name": "cantidad_detalle_metodos_pago",
        "label": "Cantidad",
        "type": "decimal",
        "required": true
      },
      {
        "name": "estado_detalle_metodos_pago",
        "label": "Estado",
        "type": "boolean",
        "required": false
      }
    ],
    "relations": [
      {
        "fk": "id_metodo_pago",
        "label": "Id metodo",
        "as": "metodoPago",
        "endpoint": "metodos_pago",
        "pk": "id_metodo_pago",
        "displayField": "nombre_metodo_pago"
      },
      {
        "fk": "id_venta",
        "label": "Id",
        "as": "venta",
        "endpoint": "ventas",
        "pk": "id_venta",
        "displayField": "fecha_venta"
      }
    ]
  }
]

export function getEntidad(nombreTabla) {
  return entidades.find((e) => e.table === nombreTabla)
}
