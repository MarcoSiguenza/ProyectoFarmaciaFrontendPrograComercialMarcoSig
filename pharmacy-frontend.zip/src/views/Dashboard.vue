<script setup>
import { ref, onMounted } from 'vue'
import api from '../services/api'

const resumen = ref(null)
const cargando = ref(true)
const error = ref('')

const tarjetas = ref([])

function formatearMoneda(valor) {
  return new Intl.NumberFormat('es-GT', { style: 'currency', currency: 'GTQ' }).format(valor || 0)
}

onMounted(async () => {
  try {
    const { data } = await api.get('/dashboard/resumen')
    resumen.value = data
    tarjetas.value = [
      { label: 'Clientes', valor: data.totalClientes, icon: '🙍', color: '#1f9d8a' },
      { label: 'Medicamentos', valor: data.totalMedicamentos, icon: '💊', color: '#3f7fbf' },
      { label: 'Proveedores', valor: data.totalProveedores, icon: '🚚', color: '#e0a52c' },
      { label: 'Ventas realizadas', valor: data.totalVentas, icon: '🛒', color: '#d9534f' }
    ]
  } catch (e) {
    error.value = 'No se pudo cargar el resumen. Verifica que la API esté corriendo.'
  } finally {
    cargando.value = false
  }
})
</script>

<template>
  <div>
    <p v-if="error" class="card" style="color: var(--color-danger)">{{ error }}</p>

    <div v-if="!error" class="grid-kpi">
      <div v-for="t in tarjetas" :key="t.label" class="card kpi">
        <div class="kpi-icon" :style="{ background: t.color + '1a', color: t.color }">{{ t.icon }}</div>
        <div>
          <p class="kpi-label">{{ t.label }}</p>
          <h3 class="kpi-valor">{{ cargando ? '...' : t.valor }}</h3>
        </div>
      </div>
    </div>

    <div v-if="!error" class="grid-secundario">
      <div class="card">
        <h4>Resumen financiero</h4>
        <div class="fila-resumen">
          <span>Total en ventas</span>
          <strong>{{ formatearMoneda(resumen?.sumaVentas) }}</strong>
        </div>
        <div class="fila-resumen">
          <span>Total en compras</span>
          <strong>{{ formatearMoneda(resumen?.sumaCompras) }}</strong>
        </div>
        <div class="fila-resumen">
          <span>Compras registradas</span>
          <strong>{{ resumen?.totalCompras ?? '-' }}</strong>
        </div>
        <div class="fila-resumen alerta" v-if="resumen">
          <span>Lotes por vencer (30 días)</span>
          <strong>{{ resumen.lotesPorVencer }}</strong>
        </div>
      </div>

      <div class="card">
        <h4>Últimas ventas</h4>
        <table v-if="resumen?.ultimasVentas?.length">
          <thead>
            <tr>
              <th>ID</th>
              <th>Cliente</th>
              <th>Fecha</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="v in resumen.ultimasVentas" :key="v.id_venta">
              <td>#{{ v.id_venta }}</td>
              <td>{{ v.cliente?.nombre_cliente || '—' }}</td>
              <td>{{ new Date(v.fecha_venta).toLocaleDateString('es-GT') }}</td>
              <td>{{ formatearMoneda(v.total_venta) }}</td>
            </tr>
          </tbody>
        </table>
        <p v-else class="vacio">Aún no hay ventas registradas.</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.grid-kpi {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 18px;
  margin-bottom: 22px;
}
.kpi {
  display: flex;
  align-items: center;
  gap: 14px;
}
.kpi-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}
.kpi-label { margin: 0; font-size: 13px; color: var(--color-text-muted); }
.kpi-valor { margin: 2px 0 0; font-size: 24px; }

.grid-secundario {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 18px;
}
@media (max-width: 900px) {
  .grid-secundario { grid-template-columns: 1fr; }
}

.fila-resumen {
  display: flex;
  justify-content: space-between;
  padding: 12px 0;
  border-bottom: 1px solid var(--color-border);
  font-size: 14px;
}
.fila-resumen:last-child { border-bottom: none; }
.fila-resumen.alerta strong { color: var(--color-warning); }
.vacio { color: var(--color-text-muted); font-size: 14px; }
</style>
