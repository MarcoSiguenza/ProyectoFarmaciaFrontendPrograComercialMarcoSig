<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import api from '../services/api'
import { getEntidad } from '../services/entities'
import EntityForm from '../components/EntityForm.vue'

const props = defineProps({ tabla: { type: String, required: true } })

const entidad = computed(() => getEntidad(props.tabla))

const registros = ref([])
const cargando = ref(true)
const error = ref('')
const busqueda = ref('')

const mostrarForm = ref(false)
const registroEditando = ref(null)
const guardando = ref(false)
const opcionesRelaciones = ref({})

// columnas visibles en la tabla: PK + primeros 4 campos propios + relaciones
const columnas = computed(() => {
  if (!entidad.value) return []
  const propios = entidad.value.fields.slice(0, 4)
  return [{ name: entidad.value.pk, label: 'ID', type: 'text' }, ...propios, ...entidad.value.relations]
})

async function cargarRegistros() {
  cargando.value = true
  error.value = ''
  try {
    const { data } = await api.get(`/${entidad.value.endpoint}`)
    registros.value = data
  } catch (e) {
    error.value = 'No se pudo cargar la información. Verifica que la API esté corriendo.'
  } finally {
    cargando.value = false
  }
}

async function cargarOpcionesRelaciones() {
  const opciones = {}
  for (const r of entidad.value.relations) {
    try {
      const { data } = await api.get(`/${r.endpoint}`)
      opciones[r.fk] = data
    } catch (e) {
      opciones[r.fk] = []
    }
  }
  opcionesRelaciones.value = opciones
}

async function cargarTodo() {
  await Promise.all([cargarRegistros(), cargarOpcionesRelaciones()])
}

onMounted(cargarTodo)
watch(() => props.tabla, cargarTodo)

const registrosFiltrados = computed(() => {
  if (!busqueda.value.trim()) return registros.value
  const q = busqueda.value.toLowerCase()
  return registros.value.filter((r) =>
    Object.values(r).some((v) => String(v ?? '').toLowerCase().includes(q))
  )
})

function abrirNuevo() {
  registroEditando.value = null
  mostrarForm.value = true
}

function abrirEditar(registro) {
  registroEditando.value = registro
  mostrarForm.value = true
}

async function guardar(payload) {
  guardando.value = true
  try {
    if (registroEditando.value) {
      await api.put(`/${entidad.value.endpoint}/${registroEditando.value[entidad.value.pk]}`, payload)
    } else {
      await api.post(`/${entidad.value.endpoint}`, payload)
    }
    mostrarForm.value = false
    await cargarRegistros()
  } catch (e) {
    alert(e.response?.data?.mensaje || 'Ocurrió un error al guardar')
  } finally {
    guardando.value = false
  }
}

async function eliminar(registro) {
  if (!confirm('¿Eliminar este registro? Esta acción no se puede deshacer.')) return
  try {
    await api.delete(`/${entidad.value.endpoint}/${registro[entidad.value.pk]}`)
    await cargarRegistros()
  } catch (e) {
    alert(e.response?.data?.mensaje || 'No se pudo eliminar el registro')
  }
}

function valorCelda(registro, columna) {
  if (columna.as) {
    // es una relación: mostrar el campo "display" del objeto incluido
    const rel = registro[columna.as]
    return rel ? rel[columna.displayField] : '—'
  }
  const valor = registro[columna.name]
  if (columna.type === 'boolean') return valor
  if (valor === null || valor === undefined || valor === '') return '—'
  return valor
}
</script>

<template>
  <div v-if="entidad">
    <div class="toolbar card">
      <input v-model="busqueda" type="search" placeholder="Buscar..." class="buscador" />
      <button class="btn btn-primary" @click="abrirNuevo">+ Nuevo {{ entidad.label.toLowerCase() }}</button>
    </div>

    <div class="card tabla-wrap">
      <p v-if="error" style="color: var(--color-danger)">{{ error }}</p>
      <p v-else-if="cargando" class="vacio">Cargando...</p>
      <p v-else-if="!registrosFiltrados.length" class="vacio">No hay registros todavía.</p>

      <table v-else>
        <thead>
          <tr>
            <th v-for="c in columnas" :key="c.name || c.fk">{{ c.label }}</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in registrosFiltrados" :key="r[entidad.pk]">
            <td v-for="c in columnas" :key="(c.name || c.fk) + r[entidad.pk]">
              <span v-if="c.type === 'boolean'" :class="['badge', valorCelda(r, c) ? 'badge-success' : 'badge-danger']">
                {{ valorCelda(r, c) ? 'Activo' : 'Inactivo' }}
              </span>
              <span v-else>{{ valorCelda(r, c) }}</span>
            </td>
            <td class="acciones">
              <button class="btn btn-outline btn-sm" @click="abrirEditar(r)">Editar</button>
              <button class="btn btn-danger btn-sm" @click="eliminar(r)">Eliminar</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <EntityForm
      v-if="mostrarForm"
      :entidad="entidad"
      :registro="registroEditando"
      :opciones-relaciones="opcionesRelaciones"
      :guardando="guardando"
      @cerrar="mostrarForm = false"
      @guardar="guardar"
    />
  </div>
</template>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 14px;
  margin-bottom: 18px;
}
.buscador { max-width: 260px; }
.tabla-wrap { overflow-x: auto; }
.vacio { color: var(--color-text-muted); padding: 20px 4px; }
.acciones { display: flex; gap: 8px; white-space: nowrap; }
</style>
