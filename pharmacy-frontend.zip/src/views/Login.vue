<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const auth = useAuthStore()

const usuario = ref('')
const password = ref('')
const cargando = ref(false)
const error = ref('')

async function enviar() {
  error.value = ''
  cargando.value = true
  try {
    await auth.login({ usuario: usuario.value, password: password.value })
    router.push({ name: 'dashboard' })
  } catch (e) {
    error.value = e.response?.data?.mensaje || 'No se pudo iniciar sesión'
  } finally {
    cargando.value = false
  }
}
</script>

<template>
  <div class="login-page">
    <div class="login-card">
      <div class="brand-icon">➕</div>
      <h1>FarmaSys</h1>
      <p class="subtitle">Sistema de gestión de farmacia</p>

      <form @submit.prevent="enviar">
        <label>Usuario</label>
        <input v-model="usuario" type="text" placeholder="admin" required />

        <label style="margin-top: 14px">Contraseña</label>
        <input v-model="password" type="password" placeholder="••••••••" required />

        <p v-if="error" class="error">{{ error }}</p>

        <button class="btn btn-primary" type="submit" :disabled="cargando" style="width: 100%; margin-top: 20px; justify-content: center;">
          {{ cargando ? 'Ingresando...' : 'Iniciar sesión' }}
        </button>
      </form>

      <p class="hint">
        Crea el primer usuario con <code>POST /api/auth/register</code> antes de iniciar sesión.
      </p>
    </div>
  </div>
</template>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(160deg, var(--color-sidebar) 0%, #0c2426 100%);
  padding: 20px;
}
.login-card {
  background: #fff;
  width: 100%;
  max-width: 380px;
  border-radius: var(--radius-lg);
  padding: 36px 32px;
  box-shadow: var(--shadow-md);
  text-align: center;
}
.brand-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  background: var(--color-primary);
  color: #fff;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 14px;
}
h1 { font-size: 22px; margin-bottom: 2px; }
.subtitle { color: var(--color-text-muted); font-size: 13px; margin-bottom: 24px; }
form { text-align: left; }
.error {
  color: var(--color-danger);
  font-size: 13px;
  margin-top: 10px;
}
.hint {
  margin-top: 22px;
  font-size: 12px;
  color: var(--color-text-muted);
  line-height: 1.5;
}
.hint code {
  background: var(--color-bg);
  padding: 2px 5px;
  border-radius: 4px;
}
</style>
