<script setup>
import { useRoute } from 'vue-router'
import { computed } from 'vue'
import { useAuthStore } from '../stores/auth'
import { getEntidad } from '../services/entities'

const route = useRoute()
const auth = useAuthStore()

const titulo = computed(() => {
  if (route.name === 'dashboard') return 'Dashboard'
  if (route.name === 'crud') {
    const e = getEntidad(route.params.tabla)
    return e ? e.label : ''
  }
  return ''
})

function cerrarSesion() {
  auth.logout()
  window.location.href = '/login'
}
</script>

<template>
  <header class="navbar">
    <div>
      <h2 class="titulo">{{ titulo }}</h2>
      <p class="ruta">Inicio / {{ titulo }}</p>
    </div>

    <div class="usuario-box">
      <div class="avatar">{{ (auth.usuario?.nombre_usuario || auth.usuario?.usuario || 'U').charAt(0).toUpperCase() }}</div>
      <div class="usuario-info">
        <strong>{{ auth.usuario?.nombre_usuario || auth.usuario?.usuario }}</strong>
        <small>{{ auth.usuario?.rol?.nombre_rol || 'Usuario' }}</small>
      </div>
      <button class="btn btn-outline btn-sm" @click="cerrarSesion">Salir</button>
    </div>
  </header>
</template>

<style scoped>
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 28px;
  background: var(--color-surface);
  border-bottom: 1px solid var(--color-border);
}
.titulo { margin: 0; font-size: 20px; }
.ruta { margin: 2px 0 0; font-size: 12px; color: var(--color-text-muted); }

.usuario-box {
  display: flex;
  align-items: center;
  gap: 12px;
}
.avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: var(--color-primary);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
}
.usuario-info { display: flex; flex-direction: column; line-height: 1.2; }
.usuario-info strong { font-size: 14px; }
.usuario-info small { color: var(--color-text-muted); font-size: 12px; }
</style>
