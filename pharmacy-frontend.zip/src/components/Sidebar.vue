<script setup>
import { getEntidad } from '../services/entities'

const grupos = [
  {
    titulo: 'General',
    items: [{ tipo: 'dashboard', label: 'Dashboard', icon: '🏠' }]
  },
  {
    titulo: 'Catálogo',
    items: ['presentaciones', 'medicamentos', 'lotes'].map((t) => getEntidad(t))
  },
  {
    titulo: 'Compras',
    items: ['casas_medicas', 'proveedores', 'compras', 'detalle_compras'].map((t) => getEntidad(t))
  },
  {
    titulo: 'Ventas',
    items: ['clientes', 'ventas', 'detalle_ventas', 'metodos_pago', 'detalle_metodos_pago'].map((t) => getEntidad(t))
  },
  {
    titulo: 'Administración',
    items: ['roles', 'usuarios'].map((t) => getEntidad(t))
  }
]
</script>

<template>
  <aside class="sidebar">
    <div class="brand">
      <span class="brand-icon">➕</span>
      <div class="brand-text">
        <strong>FarmaSys</strong>
        <small>Sistema de Farmacia</small>
      </div>
    </div>

    <nav class="menu">
      <div v-for="grupo in grupos" :key="grupo.titulo" class="grupo">
        <p class="grupo-titulo">{{ grupo.titulo }}</p>

        <router-link
          v-for="item in grupo.items"
          :key="item.label"
          :to="item.tipo === 'dashboard' ? { name: 'dashboard' } : { name: 'crud', params: { tabla: item.table } }"
          class="menu-item"
          active-class="activo"
        >
          <span class="menu-icon">{{ item.icon }}</span>
          <span>{{ item.label }}</span>
        </router-link>
      </div>
    </nav>
  </aside>
</template>

<style scoped>
.sidebar {
  width: 250px;
  min-width: 250px;
  height: 100vh;
  background: var(--color-sidebar);
  color: #dce8e7;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  position: sticky;
  top: 0;
}

.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 22px 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.brand-icon {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: var(--color-sidebar-active);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
}
.brand-text { display: flex; flex-direction: column; line-height: 1.2; }
.brand-text strong { font-family: var(--font-display); font-size: 16px; color: #fff; }
.brand-text small { font-size: 11px; color: #9db8b6; }

.menu { padding: 14px 10px 30px; flex: 1; }
.grupo { margin-bottom: 18px; }
.grupo-titulo {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #6f9391;
  padding: 0 12px;
  margin: 0 0 6px;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: var(--radius-sm);
  font-size: 14px;
  color: #cfe2e0;
  margin-bottom: 2px;
  transition: background 0.15s ease, color 0.15s ease;
}
.menu-item:hover { background: var(--color-sidebar-hover); color: #fff; }
.menu-item.activo {
  background: var(--color-sidebar-active);
  color: #fff;
  font-weight: 600;
}
.menu-icon { font-size: 16px; width: 20px; text-align: center; }
</style>
