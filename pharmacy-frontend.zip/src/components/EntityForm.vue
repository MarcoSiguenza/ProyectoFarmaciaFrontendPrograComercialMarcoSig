<script setup>
import { reactive, watch } from 'vue'

const props = defineProps({
  entidad: { type: Object, required: true },
  registro: { type: Object, default: null },
  opcionesRelaciones: { type: Object, default: () => ({}) },
  guardando: { type: Boolean, default: false }
})

const emit = defineEmits(['cerrar', 'guardar'])

const form = reactive({})

function inicializarForm() {
  Object.keys(form).forEach((k) => delete form[k])
  props.entidad.fields.forEach((f) => {
    let valor = props.registro ? props.registro[f.name] : undefined
    if (f.type === 'boolean' && valor === undefined) valor = true
    if (f.type === 'datetime-local' && valor) valor = valor.slice(0, 16)
    form[f.name] = valor ?? ''
  })
  props.entidad.relations.forEach((r) => {
    form[r.fk] = props.registro ? props.registro[r.fk] : ''
  })
}

watch(() => props.registro, inicializarForm, { immediate: true })
watch(() => props.entidad, inicializarForm)

function enviar() {
  const payload = { ...form }
  props.entidad.fields.forEach((f) => {
    if (f.type === 'number' || f.type === 'decimal') {
      payload[f.name] = payload[f.name] === '' ? null : Number(payload[f.name])
    }
  })
  props.entidad.relations.forEach((r) => {
    payload[r.fk] = payload[r.fk] === '' ? null : Number(payload[r.fk])
  })
  emit('guardar', payload)
}
</script>

<template>
  <div class="overlay" @click.self="emit('cerrar')">
    <div class="modal card">
      <div class="modal-header">
        <h3>{{ registro ? 'Editar' : 'Nuevo' }} {{ entidad.label.toLowerCase() }}</h3>
        <button class="cerrar" @click="emit('cerrar')">✕</button>
      </div>

      <form @submit.prevent="enviar" class="modal-body">
        <div v-for="f in entidad.fields" :key="f.name" class="campo">
          <label>{{ f.label }}<span v-if="f.required" class="req"> *</span></label>

          <select v-if="f.type === 'boolean'" v-model="form[f.name]">
            <option :value="true">Activo</option>
            <option :value="false">Inactivo</option>
          </select>

          <input
            v-else
            :type="f.type === 'decimal' ? 'number' : f.type"
            :step="f.type === 'decimal' ? '0.01' : undefined"
            v-model="form[f.name]"
            :required="f.required"
          />
        </div>

        <div v-for="r in entidad.relations" :key="r.fk" class="campo">
          <label>{{ r.label }}</label>
          <select v-model="form[r.fk]" required>
            <option value="" disabled>Selecciona...</option>
            <option
              v-for="opcion in (opcionesRelaciones[r.fk] || [])"
              :key="opcion[r.pk]"
              :value="opcion[r.pk]"
            >
              {{ opcion[r.displayField] || ('#' + opcion[r.pk]) }}
            </option>
          </select>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-outline" @click="emit('cerrar')">Cancelar</button>
          <button type="submit" class="btn btn-primary" :disabled="guardando">
            {{ guardando ? 'Guardando...' : 'Guardar' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(18, 58, 61, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 50;
  padding: 20px;
}
.modal {
  width: 100%;
  max-width: 460px;
  max-height: 88vh;
  display: flex;
  flex-direction: column;
  padding: 0;
  overflow: hidden;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 22px;
  border-bottom: 1px solid var(--color-border);
}
.modal-header h3 { text-transform: capitalize; }
.cerrar {
  background: none;
  border: none;
  font-size: 16px;
  color: var(--color-text-muted);
}
.modal-body {
  padding: 20px 22px;
  overflow-y: auto;
}
.campo { margin-bottom: 14px; }
.req { color: var(--color-danger); }
.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 8px;
  padding-top: 12px;
  border-top: 1px solid var(--color-border);
}
</style>
