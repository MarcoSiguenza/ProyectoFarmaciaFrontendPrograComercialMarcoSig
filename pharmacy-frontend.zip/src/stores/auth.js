import { defineStore } from 'pinia'
import api from '../services/api'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('farmacia_token') || null,
    usuario: JSON.parse(localStorage.getItem('farmacia_usuario') || 'null')
  }),
  getters: {
    estaAutenticado: (state) => !!state.token
  },
  actions: {
    async login(credenciales) {
      const { data } = await api.post('/auth/login', credenciales)
      this.token = data.token
      this.usuario = data.usuario
      localStorage.setItem('farmacia_token', data.token)
      localStorage.setItem('farmacia_usuario', JSON.stringify(data.usuario))
    },
    logout() {
      this.token = null
      this.usuario = null
      localStorage.removeItem('farmacia_token')
      localStorage.removeItem('farmacia_usuario')
    }
  }
})
