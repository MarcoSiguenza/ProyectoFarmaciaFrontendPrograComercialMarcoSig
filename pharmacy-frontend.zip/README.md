# Frontend - Sistema de Farmacia

Interfaz construida con **Vue 3 + Vite**, inspirada en paneles de administración tipo dashboard
(sidebar oscuro, tarjetas KPI y tablas), con un CRUD genérico reutilizable para las 14 entidades
del sistema.

## Estructura

```
pharmacy-frontend/
├── src/
│   ├── components/
│   │   ├── Sidebar.vue        # Menú lateral agrupado (Catálogo, Compras, Ventas, Administración)
│   │   ├── Navbar.vue         # Barra superior con usuario y logout
│   │   └── EntityForm.vue     # Modal de formulario genérico (crear/editar)
│   ├── layouts/
│   │   └── DashboardLayout.vue
│   ├── views/
│   │   ├── Login.vue
│   │   ├── Dashboard.vue      # Tarjetas KPI + últimas ventas
│   │   └── EntityView.vue     # Listado + CRUD genérico, según la tabla en la ruta
│   ├── services/
│   │   ├── api.js             # Instancia axios con JWT interceptor
│   │   └── entities.js        # Configuración de las 14 entidades (campos, relaciones, labels)
│   ├── stores/
│   │   └── auth.js            # Pinia store de autenticación
│   ├── router/index.js
│   ├── style.css              # Tokens de diseño (colores, tipografía, componentes base)
│   └── main.js
└── index.html
```

## ¿Cómo funciona el CRUD genérico?

En lugar de crear 14 vistas casi idénticas, `EntityView.vue` lee la configuración de
`services/entities.js` (generada a partir del mismo diagrama que el backend) y construye:

- Las columnas de la tabla (incluye llaves foráneas mostrando el nombre relacionado, no el ID).
- El formulario del modal, incluyendo `<select>` para las relaciones (por ejemplo, al crear un
  `Medicamento` se listan las `Presentaciones` disponibles).
- Las llamadas a la API según el endpoint de cada entidad.

Las rutas quedan como `/crud/:tabla`, por ejemplo `/crud/medicamentos`, `/crud/ventas`, etc.
El menú lateral ya enlaza a todas ellas agrupadas por módulo.

## Instalación

```bash
npm install
cp .env.example .env
# Edita VITE_API_URL si tu backend no corre en localhost:3000
```

## Ejecución

```bash
npm run dev       # http://localhost:5173
npm run build     # genera /dist para producción
```

## Primer acceso

El login requiere un usuario ya creado en la base de datos. Crea el primero llamando a:

```
POST http://localhost:3000/api/auth/register
Content-Type: application/json

{
  "usuario": "admin",
  "password": "admin123",
  "nombre_usuario": "Administrador",
  "id_rol": 1
}
```

(El rol `1` = Administrador viene precargado por el script SQL). Luego inicia sesión desde la
pantalla de Login del frontend.
